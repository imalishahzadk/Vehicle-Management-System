<?php 
require 'action_bus_schedule.php';
require 'action_location.php';
require 'action_vehicle.php';

//  function redirect(){
//     header("location:admin.php",true,02);
//      die();
//  }  
//  function direct(){
//     header("location:admin.php",true,02);
//     die();
// }     

class Technical_layer{
   
/////////////////////////////////////////////////  FETCHING VEHICLE SCHEDULE /////////////////////////

    function fetch_vehicle_schedule_from_DB()  // and sending to bus schedule class
    {
       
        $location = new Location();
        $vehicle = new Vehicle();
        $vehicle_schedule =  new Vehicle_Schedule($location, $vehicle);
        echo "";
        $conn = mysqli_connect("localhost","root","","bus");
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $result = mysqli_query($conn, "SELECT vs.scheduleID, vs.departureTime, loc.pickUpLocation,loc.dropOffLocation,
                                       v.vehicleNO,v.vehicleType
                                       FROM vehicle_schedule vs
                                       LEFT JOIN location loc
                                       ON vs.locID = loc.locID
                                       LEFT JOIN vehicle v
                                       ON vs.vehicleID = v.vehicleNO");   



echo "<table class='table table-bordered table-hover'>
<thead class='thead-dark'>
  <tr>
    <th>Departure Time</th>
    <th>Starting Location</th>
    <th>Route</th>
    <th>Vehicle Number</th>
    <th>Vehicle Type</th>
  </tr>
</thead>
<tbody>";
        //echo(mysqli_fetch_assoc($result));
         while($row = mysqli_fetch_assoc($result)) {

            $vehicle_schedule->set_departure_time($row["departureTime"]); 
            $vehicle_schedule->set_location( $row["pickUpLocation"], $row["dropOffLocation"]); 
            $vehicle_schedule->set_vehicle_num($row["vehicleNO"]); 
            $vehicle_schedule->set_vehicle_type( $row["vehicleType"]); 
            $vehicle_schedule->send_data_to_display_class ();
           // $vehicle_schedule->display();
            
            // echo $row["departureTime"];
            
         }
            echo "</tbody></table>";

mysqli_close($conn);       

    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////



} // class ending bracket

?>