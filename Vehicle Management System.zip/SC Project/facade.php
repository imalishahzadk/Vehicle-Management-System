<?php 
class Technical_layer{

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            
    function add_bs_ToDB($d_time, $starting_loc, array $route, $vehicleNumber, $vehicleType,$vehicleStatus ) {
        $conn = mysqli_connect('localhost', 'root', '', 'bus');

        
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }   
        $route_string = implode(",", $route);



        $sql = "INSERT INTO vehicle (vehicleNO, vehicleType,vehicleStatus)
        VALUES ('$vehicleNumber', '$vehicleType','$vehicleStatus')";
    
        if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        $sql = "INSERT INTO location (pickUpLocation, dropOffLocation) VALUES ('$starting_loc', '$route_string')";
         if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        // Insert the data into the table
        $sql = "INSERT INTO vehicle_schedule (departureTime,vehicleID,locID)VALUES ('$d_time','$vehicleNumber',LAST_INSERT_ID())";
         if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        mysqli_close($conn);
       
        // checks
        // $result_veh_No = mysqli_query($conn, "SELECT * FROM vehicle WHERE vehicleNO = '$vehicleNumber'");
        
        // if (mysqli_num_rows($result_veh_No) == 0) 
        // {
        //     $sql = "INSERT INTO vehicle (vehicleNO, vehicleType,vehicleStatus)
        //     VALUES ('$vehicleNumber', '$vehicleType','$vehicleStatus')";
        
        //     if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }
    
        //     $sql = "INSERT INTO location (pickUpLocation, dropOffLocation) VALUES ('$starting_loc', '$route_string')";
        //      if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }
    
        //     // Insert the data into the table
        //     $sql = "INSERT INTO vehicle_schedule (departureTime,vehicleID,locID)VALUES ('$d_time',LAST_INSERT_ID(),LAST_INSERT_ID())";
        //      if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }
          
        // } 
        // else
        // {

        //     // SELECT * FROM `vehicle_schedule` WHERE `vehicleID` = 6 AND `departureTime` LIKE '12:18' ;


        //     $result_d_time = mysqli_query($conn, "SELECT * FROM vehicle_schedule WHERE vehicleNO = '$vehicleNumber'");
        //     while($row = mysqli_fetch_assoc($result_d_time)) 
        //     {
        //        if ($row['departureTime'] == $d_time)
        //        {
        //             echo "One bus can not have more than 1 same departure time";
        //             exit();
        //        }        
        //     }
        //     // otherwise add to DB

        //     $sql = "INSERT INTO vehicle (vehicleNO, vehicleType,vehicleStatus)
        //     VALUES ('$vehicleNumber', '$vehicleType','$vehicleStatus')";
        
        //     if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }
    
        //     $sql = "INSERT INTO location (pickUpLocation, dropOffLocation) VALUES ('$starting_loc', '$route_string')";
        //      if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }
    
        //     // Insert the data into the table
        //     $sql = "INSERT INTO vehicle_schedule (departureTime,vehicleID,locID)VALUES ('$d_time',LAST_INSERT_ID(),LAST_INSERT_ID())";
        //      if (mysqli_query($conn, $sql)) {
        //         echo "New record created successfully";
        //     } else {
        //         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        //     }

        }

       
        // Close the connection
        // mysqli_close($conn);
        // redirect();
        
    
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function add_requisition_ToDB( $a_time, $d_time, $req, $reqID,$date, array $route, $starting_loc)
    {


             $conn = mysqli_connect('localhost', 'root', '', 'bus');

    
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }   
        $r_string = implode("", $route);

        // checks

        


        $sql = "INSERT INTO location (pickUpLocation, dropOffLocation) VALUES ('$starting_loc', '$r_string')";
         if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        $sql = "INSERT INTO requisition (request, departure_time,reqDate,arrivalTime,locID)
        VALUES ('$req','$d_time','$date', '$a_time',LAST_INSERT_ID())";
    
        if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }


    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function add_user_data_toDB($id, $password, $designation )
    {
        ///////////////////////////// addd query
        // 
        $conn = mysqli_connect('localhost', 'root', '', 'bus');

    
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }   


        $sql = "INSERT INTO user (username, designation,password) VALUES ('$id', '$designation','$password')";
    
        if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);

        }
    }

    function add_complaint_ToDB($complaint )
    {
        /////////////////////////////// addd query
        // echo $cID;
        // echo $user_ID;
        // echo $complaint;
         $conn = mysqli_connect('localhost', 'root', '', 'bus');

    
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }   


        $sql = "INSERT INTO complaints (complaint) VALUES ('$complaint')";
    
        if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//    function add_maintenance_record_toDB ( $date, $num, $type, $status)
//    {
//        // Check connection
//        if (!$conn) {
//         die("Connection failed: " . mysqli_connect_error());
//     }   
//     $route_string = implode(",", $route);



//     $sql = "INSERT INTO vehicle (vehicleNO, vehicleType,vehicleStatus)
//     VALUES ('$vehicleNumber', '$vehicleType','$vehicleStatus')";

//     if (mysqli_query($conn, $sql)) {
//         echo "New record created successfully";
//     } else {
//         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//     }

//     $sql = "INSERT INTO location (pickUpLocation, dropOffLocation) VALUES ('$starting_loc', '$route_string')";
//      if (mysqli_query($conn, $sql)) {
//         echo "New record created successfully";
//     } else {
//         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//     }

//     // Insert the data into the table
//     $sql = "INSERT INTO vehicle_schedule (departureTime,vehicleID,locID)VALUES ('$d_time','$vehicleNumber',LAST_INSERT_ID())";
//      if (mysqli_query($conn, $sql)) {
//         echo "New record created successfully";
//     } else {
//         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//     }

//     mysqli_close($conn);

//    }

}

?>