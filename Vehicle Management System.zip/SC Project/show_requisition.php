

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha84-Gn584xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E26XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!DOCTYPE html>
<html>
<head>
    <title>Show Requisition</title>
</head>
<body>
<h2 class="text-center">Requisitions</h2>
</body>
<?php
    // Connect to the database
    $conn = mysqli_connect("localhost","root","","bus");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // Fetch data from the "vehicle_schedule" and "location" tables
    $result = mysqli_query($conn, "SELECT req.reqID, req.request,req.departure_time,req.arrivalTime, req.reqDate,loc.pickUpLocation,loc.dropOffLocation
                                                          FROM requisition req
                                                          LEFT JOIN location loc
                                                          ON req.locID = loc.locID");   
    

                                                                               
    echo "<table class='table table-bordered table-hover'>
              <thead class='thead-dark'>
                <tr>
                  <th>Requisition Desc</th>
                  <th>Departure Time</th>
                  <th>Arrival Time</th>
                  <th>Request Date</th>
                  <th>PickUp Location</th>
                  <th>Routes</th>
                </tr>
              </thead>
              <tbody>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                  <td>".$row["request"]."</td>
                  <td>".$row["departure_time"]."</td>
                  <td>".$row["arrivalTime"]."</td>
                  <td>".$row["reqDate"]."</td>
                  <td>".$row["pickUpLocation"]."</td>
                  <td>".$row["dropOffLocation"]."</td>
              </tr>";
    }
    echo "</tbody></table>";
    mysqli_close($conn);
?>
