<?php 

?>
<!DOCTYPE html>
<head>
    <title>Add Bus Status</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body class="p-3 mb-2 bg-dark text-white"></body>
    <h1 class="d-flex justify-content-center">University Bus Management System</h1>
    <h2 class="d-flex justify-content-center mb-4">Add Bus Status</h2>
    <form method="POST" action="/php_facade.php">
 
        <!-- Row 1 -->
        <div class="form-group row pt-4 mb-4 ">
            <div class="col-lg-1 pt-0">
            </div>
            <div class="col-lg-3 pt-0">
                <h3>Maintenance Officer</h3>
            </div>
            <div class="col-lg-5 pt-0">
            </div>
            <div class="col-lg-3 pt-0">
                <!-- <h3>HOD</h3> -->
            </div>
        </div>  
        <!-- Row 2 -->
        <div class="form-group row pt-4 mb-0 ">
            <div class="col-lg-1 pt-0">
            </div>
            <div class="col-lg-2 pt-0">
                <a href="./view_schedules_hod.html" class="link-warning">View Schedule</a>
            </div>
            <div class="col-lg-1 pt-0">
            </div>

            <div class="col-lg-2 pt-0">
                <label for="v-id">Vehicle Number</label>
            </div>
            <div class="col-lg-2 pt-0">
                <input type="text" class="form-control" id="v-id" name="vehicle_id" value="" minlength="3" >
            </div>
            <div class="col-lg-1 pt-0">
            </div>
            <div class="col-lg-3 pt-0">
                <a href="./add_bus_s.html" class="link-warning">Add Bus Schedule</a>

            </div>
        </div>  
             <!--Row 3  -->

       <div class="form-group row pt-2 mb-0 ">
          <div class="col-lg-1 pt-0">
          </div>
          <div class="col-lg-2 pt-0">
              <a href="./search_schedule_hod.html" class="link-warning">Search Vehicle Schedule</a>
          </div>
          <div class="col-lg-1 pt-0">
          </div>
          <div class="col-lg-2 pt-0">
            <label for="v-type" >Vehicle Type</label>
        </div>
        <div class="col-lg-2 pt-0">
            <input type="text" class="form-control" id="v-type" name="v-type"  value="" minlength="3" >
        </div>
          <div class="col-lg-1 pt-0">
        </div>
        <div class="col-lg-3 pt-0">
            <a href="./add_bus_s.html" class="link-warning">Add Bus Schedule</a>

        </div>
      </div> 
      <!--  ///////////////////////////////////////////////////// -->




                         <!--Row 4  -->

      <div class="form-group row pt-4 mb-0 ">
         <div class="col-lg-1 pt-0">
         </div>
         <div class="col-lg-2 pt-0">
             <a href="./search_req_hod.html" class="link-warning">Search Requisition</a>
         </div>
         <div class="col-lg-1 pt-0">
        </div>
        <div class="col-lg-2 pt-0">
            <span>Date of damage</span>
        </div>
         <div class="col-lg-3 pt-0">
            <div class="form-check">
                <input class="form-check-input" type="date" name="date_of_damage" id="dod" checked>
                <!-- <label class="form-check-label" for="flexRadioDefault1">
                  
                </label> -->
              </div>
         </div>

 
        <div class="col-lg-3 pt-0">
            <a href="./add_bus_s.html" class="link-warning">Add Bus Schedule</a>

        </div>
     </div> 
                         
     <!--Row 5 -->

     <div class="form-group row pt-4 mb-0 ">
        <div class="col-lg-1 pt-0">
        </div>
        <div class="col-lg-2 pt-0">
            <a href="./search_req_hod.html" class="link-warning">Update Requisition </a>
        </div>
        <div class="col-lg-1 pt-0">
        </div>
 
        <div class="col-lg-1 pt-0">

        </div>
        <div class="d-flex justify-content-center mt-4"><button type="submit" class="btn btn-secondary btn-lg">Add Bus status</button></div>

        <div class="col-lg-3 pt-0">
        </div>
        <div class="col-lg-1 pt-0">
        </div>
        <div class="col-lg-3 pt-0">

        </div>
    </div> 

    
  
    

      




      </form>


<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------ -->


</body>
</html>