

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha84-Gn584xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E26XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!DOCTYPE html>
<html>
<head>
    <title>Show Bus Schedule</title>
</head>
<body>
<h2 class="text-center">Vehicle Schedule</h2>
</body>
<?php

    // Connect to the database
   require 'facadeFetch.php';
   
function display_schedule($d_time, $pick_up, $route, $number, $type)
{


echo 
"<tr>
<td>".$d_time."</td>
<td>".$pick_up."</td>
<td>".$route."</td>
<td>".$number."</td>
<td>".$type."</td>
</tr>";

}




   
$db_layer = new Technical_layer();
$db_layer->fetch_vehicle_schedule_from_DB() ;
       

?>