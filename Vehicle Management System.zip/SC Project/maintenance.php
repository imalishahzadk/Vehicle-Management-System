<?php


class Maintenance{
    private $vehicle;
    private $date_of_damage;  
    private $date_of_recovery;

#constructor
    function __construct( Vehicle $v)  {

        $this->vehicle = $v;
        $this->date_of_damage = "";
        $this->date_of_recovery="";
      }

    function set_DO_Damage($date)
    {
      $this->date_of_damage = $date;
    }

    function set_DO_Recovery($date)
    {
      $this->date_of_recovery = $date;
    }

    function get_DO_Damage()
    {
      return $this->date_of_damage;
    }

    function get_DO_Recovery()
    {
      return $this->date_of_recovery;
    }

    function set_vehicle_num($v_number) {
        $this->vehicle->set_vehicle_num($v_number);
    } 

    function set_vehicle_type($v_type) {
      $this->vehicle->set_vehicle_type($v_type);
  }


  function set_veh_status($status) {
    $this->vehicle->set_vehicle_status($status);
}
function get_veh_status() {
  return $this->vehicle->get_vehicle_status();
}

function get_vehicle_type()
  {
    return $this->vehicle->get_vehicle_type() ;
  }

  function get_vehicle_num()
  {
    return $this->vehicle->get_vehicle_num();
  }

function send_maintenanceData_toFacade()
{
  require_once 'facade.php';
  $db_layer = new Technical_layer();
  $db_layer->add_maintenance_record_toDB( $this->get_DO_Damage(), $this->get_vehicle_num() ,$this->get_vehicle_type(),  $this->get_veh_status());
}  

      function Display()
{
    return $this->get_veh_status();
  // return $this->get_vehicle_num() . $this->get_vehicle_type() ."       ". $this->get_veh_status(). "          " . $this->get_DO_Damage();
}
 
}



?>