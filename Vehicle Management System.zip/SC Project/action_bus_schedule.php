<?php
// require 'action_location.php';
// require 'action_vehicle.php';
// require 'facade.php';
//require 'show_bus_schedule.php';


// echo $_POST;
// exit();
// echo $_POST['routes'];
// echo $_POST['d_time'];
// echo $_POST['vehicle_type'];
// echo $_POST['vehicle_no'];]


class Vehicle_Schedule{
    private $departure_time;
    private $location;  
    private $vehicle;  

#constructor
    function __construct(Location $loc, Vehicle $v)  {
        $this->vehicle = $v;
        $this->location = $loc;
      }

      
    function set_location($loc, $route)
    {
      $this->location->set_start_loc($loc);   
      $this->location->set_route($route);
    }         
    function set_departure_time($d_time) {
      $this->departure_time = $d_time;
    } 
    function set_vehicle_num($v_number) {
        $this->vehicle->set_vehicle_num($v_number);
    } 
    function set_vehicle_type($v_type) {
      $this->vehicle->set_vehicle_type($v_type);
  }
  function get_starting_point()
  {
   return $this->location->get_start_loc();
  }  

  function get_routes()
  {
   return $this->location->get_route();
  } 

  function get_vehicle_type()
  {
    return $this->vehicle->get_vehicle_type() ;
  }

  function get_vehicle_num()
  {
    return $this->vehicle->get_vehicle_num();
  }
  
  function get_departure_time() {
        return $this->departure_time;        
      }  

   ////////////////////////////////  Sending to Facade ////////////////
  function send_BS_toFacade()
  {
    require 'facade.php';
    $db_layer = new Technical_layer();
    $db_layer->add_bs_ToDB( $this->get_departure_time(), $this->get_starting_point(), $this->get_routes(), $this->get_vehicle_num(), $this->get_vehicle_type(),$this->vehicle->get_vehicle_status());
  }  
 
  //////////////////////////////////////////  Sending data to Show Vehicle Schedule Class ///////////////


 
  function send_data_to_display_class ()
  {  
        display_schedule($this->get_departure_time(), $this->get_starting_point(), $this->get_routes(), $this->get_vehicle_num(), $this->get_vehicle_type());
//   
    }
   // echo "</tbody></table>";
    function display()
    {
      echo $this->get_departure_time(). $this->get_starting_point(). $this->get_routes(). $this->get_vehicle_num(). $this->get_vehicle_type();

    } 


   
}

?>
