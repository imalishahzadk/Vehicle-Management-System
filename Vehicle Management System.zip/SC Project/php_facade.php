<?php


class php_facade{

     function __construct()
     {

     }

     function store_VSchedule_data_to_phpClass()
     {
        require_once 'action_bus_schedule.php';
        require 'action_location.php';
        require 'action_vehicle.php';

        $location = new Location();
        $vehicle = new Vehicle();
        $vehicle_schedule =  new Vehicle_Schedule($location, $vehicle );
        $vehicle_schedule->set_departure_time($_POST['d_time_for_bs']); //$_POST['d_time']
        $vehicle_schedule->set_location( $_POST["Start_point"],  array($_POST["routes"]));  // $_POST["Start_point"], $_POST["routes"]
        $vehicle_schedule->set_vehicle_num($_POST["vehicle_no"]); //$_POST["vehicle_no"]
        $vehicle_schedule->set_vehicle_type( $_POST["transportation"]); // $_POST["vehicle_type"]
        $vehicle_schedule->send_BS_toFacade();
     // $vehicle_schedule->display();
         }
    
    function store_requisition_to_phpClass () {

       require_once 'action_make_requisition.php';
       require_once 'action_location.php';
       $location = new Location();
       $requisition =  new Requisition($location);
       $requisition->set_departure_time($_POST['d_time']);
       $requisition->set_arrival_time($_POST['a_time']);
       $requisition->set_location( $_POST["Start_point"], array( $_POST["route"]));
       $requisition->set_date($_POST["Date"]); 
       $requisition->set_requisitionID($_POST["req_id"]); 
       $requisition->set_arrival_time($_POST["a_time"]); 
       $requisition->set_requisition($_POST["requisition"]); 

       $requisition->send_req_Data_toFacade();

    }

    function store_maintenance_data_to_phpClass()     // issue in updating bus status
    {
        require_once 'maintenance.php';
        require_once 'action_vehicle.php';
        $status = 0;

        $vehicle = new Vehicle();
        $maintain = new Maintenance($vehicle);
        $maintain->set_DO_Damage($_POST["date_of_damage"]);    
        $maintain->set_veh_status($status);                    //             <------------- There
        $maintain->set_vehicle_num($_POST["vehicle_id"]); 
        $maintain->set_vehicle_type($_POST["v-type"]); 
        $maintain->send_maintenanceData_toFacade();
        // echo $maintain->Display();

    }

    function store_userData_to_phpClass()
    {
        require_once 'action_signup.php';

      $user = new Users();
      $user->set_ID($_POST["id"]);
      $user->set_password($_POST["password"]);  
      $user->set_designation($_POST["designation"]);
      $user->send_user_data_to_Facade();
    //   echo $user->display();   
     }
    
}//class ending brackets

$facade_obj = new php_facade();

if(isset($_POST['d_time_for_bs'])) {
    $facade_obj->store_VSchedule_data_to_phpClass();
    }
else    
if(isset($_POST['requisition'])) {
    $facade_obj->store_requisition_to_phpClass ();
    }    
else 
if (isset($_POST['date_of_damage']))   
{
    $facade_obj->store_maintenance_data_to_phpClass();          
} 
else
if (isset($_POST["designation"]))
{
    $facade_obj->store_userData_to_phpClass();
             
}




?>