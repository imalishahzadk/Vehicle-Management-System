$(document).ready(function() { 
    $( "#submit" ).on( "click", function() {

     let rid = $('#rid').val()
     $('.errorMsg').hide()
            if(PickLoc(ploc) == false){   
                $('#errorPickLoc').show();   
                $('#ploc').animate({left: '-=10px'}, 20, function() {console.log('Animate Completed')}); 
                $('#ploc').animate({left: '+=10px'}, 20, function() {console.log('Animate Completed')})
                
                return false;    
            }   
    })
})

function RID(rid){
    let rid_pattern = /^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$/
    if(rid_pattern.test(rid)){
        return true;
    }else{
        return false;
    }
}