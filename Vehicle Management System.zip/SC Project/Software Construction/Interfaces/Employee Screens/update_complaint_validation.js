$(document).ready(function() { 
    $( "#submit" ).on( "click", function() {
        
     let uComplaints = $('#uComplaints').val()
     let id = $('#id').val()
    //  let time = $('#time').val();
     $('.errorMsg').hide()
     
     if(UComplaints(uComplaints) == false){   
           $('#errorUComplaints').show();   
           $('#uComplaints').animate({left: '-=10px'}, 20, function() {console.log('Animate Completed')});
           $('#uComplaints').animate({left: '+=10px'}, 20, function() {console.log('Animate Completed')});
           
           return false;    
     }
     else if(ID(id) == false){   
        $('#errorID').show();   
        $('#id').animate({left: '-=10px'}, 20, function() {console.log('Animate Completed')}); 
        $('#id').animate({left: '+=10px'}, 20, function() {console.log('Animate Completed')})
        
        return false;    
        }
    })
})

function UComplaints(uComplaints){
    let uComplaint_pattern = /^[a-zA-Z0-9_\s@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]{1,75}$/
    if(uComplaint_pattern.test(uComplaints)){
        return true;
    }else{
        return false;
    }
}

function ID(id){
    let id_pattern = /^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$/
    if(id_pattern.test(id)){
        return true;
    }else{
        return false;
    }
}