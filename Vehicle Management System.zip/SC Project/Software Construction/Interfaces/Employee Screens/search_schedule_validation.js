$(document).ready(function() { 
    $( "#btn3" ).on( "click", function() {
        
     let searchSchedule = $('#searchSchedule').val()
    //  let id = $('#id').val()
    //  let time = $('#time').val();
     $('.errorMsg').hide()
     
     if(searchBusSchedule(searchSchedule) == false){   
           $('#errorsearchSchedule').show();   
           $('#searchSchedule').animate({left: '-=10px'}, 20, function() {console.log('Animate Completed')});
           $('#searchSchedule').animate({left: '+=10px'}, 20, function() {console.log('Animate Completed')});
           
           return false;    
     }
    })
})

function searchBusSchedule(searchSchedule){
    let searchSchedule_pattern = /^[a-zA-Z0-9_\s@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]{1,75}$/
    if(searchSchedule_pattern.test(searchSchedule)){
        return true;
    }else{
        return false;
    }
}