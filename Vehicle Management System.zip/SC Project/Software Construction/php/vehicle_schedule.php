<?php
require_once 'location.php';
require_once 'vehicle.php';
echo $_POST;
class Vehicle_Schedule{
    private $departure_time;
    private $location;  
    private $vehicle;

#constructor
    function __construct(Location $loc, Vehicle $v)  {

        $this->vehicle = $v;
        $this->location = $loc;
      }

    function set_location($loc, array $route)
    {
      $this->location->set_start_loc($loc);   
      $this->location->set_route($route);
    }         
    function set_departure_time($d_time) {
      $this->departure_time = $d_time;
    } 
    function set_vehicle_num($v_number) {
        $this->vehicle->set_vehicle_num($v_number);
    } 
    function set_vehicle_type($v_type) {
      $this->vehicle->set_vehicle_type($v_type);
  }
  function get_location()
  {
   echo  $this->location->get_start_loc(). PHP_EOL ;   
   echo  $this->location->get_route(). PHP_EOL ;
  }  
  function get_vehicle_data()
  {
    echo $this->vehicle->get_vehicle_type(). PHP_EOL ;
    echo $this->vehicle->get_vehicle_num(). PHP_EOL ;

  }
  function get_departure_time() {
        return $this->departure_time;        
      }   
    // function get_vehicle_num() {
    //   return $this->vehicle_num;        
    // }   
}

$location = new Location();
$vehicle = new Vehicle();
$vehicle_schedule =  new Vehicle_Schedule($location, $vehicle );
$vehicle_schedule->set_departure_time("12:00 AM");
$vehicle_schedule->set_location("QAU", array("pindi point","G9"));
// $vehicle->set_vehicle_type("Bus");
// $vehicle->set_vehicle_num("b-457");
$vehicle_schedule->set_vehicle_num("number-2343");
$vehicle_schedule->set_vehicle_type("Van Dam");


// echo $vehicle_schedule->get_departure_time(). PHP_EOL ;
// $vehicle_schedule->get_location();
// $vehicle_schedule->get_vehicle_data() ;
?>
