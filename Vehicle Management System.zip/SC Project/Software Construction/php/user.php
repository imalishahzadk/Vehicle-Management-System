<?php 
class Users{
    private $ID;
    private $password;
    private $designation;
#constructor
    function __construct()  {
        $this->ID= "";
        $this->password= "";
        $this->designation= "";
      }
    function set_ID($id) {
      $this->ID = $id;
    } 
    function set_password($p) {
        $this->password = $p;
    } 
    function set_designation($d) {
        $this->designation = $d;
    } 
    function get_ID() {
        return $this->ID;
      }   
      function get_password() {
        return $this->password;
    }  
    function get_designation() {
       return $this->designation;
    } 

}

$user = new Users();
$user->set_ID("Id-1276");
$user->set_password("pass-5432");
$user->set_designation("Students");
echo $user->get_ID();
echo $user->get_designation();
echo $user->get_password();

?>
