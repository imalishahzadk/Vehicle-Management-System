<?php
define('DB_SYS','mysql');
define('DB_HOST','localhost');
define('DB_NAME','login');
define('DB_USER','root');
define('DB_PASS','');
?>