<?php
require_once('Vehicle.php');
class Maintenance
{
    private $vehicle;
    private $vehicle_status;
    private $date_of_damage;
    private $date_of_recovery;

    #constructor
    function __construct(Vehicle $v)
    {
        $this->vehicle = $v;
        $this->vehicle_status = "";
        $this->date_of_damage = "";
        $this->date_of_recovery = "";
    }

    function set_vehicleData($v_number, $v_type)
    {
        $this->vehicle->set_vehicle_num($v_number);
        $this->vehicle->set_vehicle_type($v_type);
    }


    function set_vehicle_status($status)
    {
        $this->vehicle_status = $status;
    }
    function set_date_of_damage($d)
    {
        $this->date_of_damage = $d;
    }

    function set_date_of_recovery($d)
    {
         $this->date_of_recovery = $d;
    }


    function get_vehicleData()
    {
        echo $this->vehicle->get_vehicle_num();
        echo $this->vehicle->get_vehicle_type();
    }
    function get_vehicle_status()
    {
        return $this->vehicle_status;
    }
    function get_date_of_damage()
    {
        return $this->date_of_damage;
    }
    function get_date_of_recovery()
    {
        return $this->date_of_recovery;
    }
}


// $vehicle =  new Vehicle();
// $vehicle->set_vehicle_type("Bus");
// $vehicle->set_vehicle_num("b-457");

// echo $vehicle ->get_vehicle_type();
// echo $vehicle ->get_vehicle_num();
?>