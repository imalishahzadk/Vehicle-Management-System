<?php
require_once 'location.php';
require_once 'vehicle.php';
// echo $_POST;
//  exit();

class Requisition{
    private $departure_time;
    private $arrival_time;
    private $location;  
    private $date;
    private $requisition_id;

#constructor
    function __construct(Location $loc)  {
        $this->arrival_time = "";
        $this->departure_time = "";
        $this->date = "";
        $this->requisition_id = "";
        $this->location = $loc;
      }

    function set_location($loc, $route)
    {
      $this->location->set_start_loc($loc);   
      $this->location->set_route($route);
    }         
    function set_departure_time($d_time) {
      $this->departure_time = $d_time;
    } 
    function set_arrival_time($a_time) {
        $this->arrival_time = $a_time;
      } 
    function set_requisitionID($id)
    {
        $this->requisition_id = $id;
    }
    
    function set_date($date)
    {
         $this->date = $date;
    }
  function get_location()
  {
   echo  $this->location->get_start_loc(). PHP_EOL ;
    echo $this->location->get_route();
  }  
  function get_date()
  {
        return $this->date;
  }
  function get_requisitionID()
  {
        return $this->requisition_id;
  }
  function get_departure_time() {
        return $this->departure_time;        
      }   

 function get_arrival_time() {
   $this->arrival_time ;
 }     
}

$location = new Location();
$requisition =  new Requisition($location);
$requisition->set_departure_time($_POST['d_time']);
$requisition->set_location( $_POST["p_loc"], $_POST["route"]);  // $_POST["Start_point"], $_POST["routes"]
$requisition->set_date($_POST["Date"]);
$requisition->set_requisitionID($_POST["req_id"]);
$requisition->set_arrival_time($_POST["a_time"]);


echo $requisition->get_departure_time(). PHP_EOL ;
$requisition->get_location();
$requisition->get_arrival_time();
$requisition->get_date();
$requisition->get_requisitionID();
?>