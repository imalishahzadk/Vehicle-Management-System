<?php
//  require_once 'facade.php';
//  require_once 'php_facade.php';
//echo $_POST["userID"];
class Users{
    private $ID;
    private $password;
    private $designation;
#constructor
    function __construct()  {
        $this->ID= "";
        $this->password= "";
        $this->designation= "";
      }
    function set_ID($id) {
      $this->ID = $id;
    } 
    function set_password($p) {
        $this->password = $p;
    } 
    function set_designation($d) {
        $this->designation = $d;
    } 
    function get_ID() {
        return $this->ID;
      }   
      function get_password() {
        return $this->password;
    }  
    function get_designation() {
       return $this->designation;
    } 

    function send_user_data_to_Facade()
    {
    require_once 'facade.php';
    $db_layer = new Technical_layer();
    $db_layer->add_user_data_toDB($this->get_ID(), $this->get_password(), $this->get_designation());
    }
  
    function display()
    {
      return $this->get_ID() . $this->get_designation() . $this->get_password();
    }

}



?>
