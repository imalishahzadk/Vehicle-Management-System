<?php
require_once 'vehicle.php';
require_once 'facade.php';
class Maintenance{
    private $vehicle;
    private $date_of_damage;  
    private $date_of_recovery;
    private $facade_obj;

#constructor
    function __construct(Technical_layer $f, Vehicle $v)  {

        $this->vehicle = $v;
        $this->facade_obj= $f;
        $this->date_of_damage = "";
        $this->date_of_recovery="";
      }

    function set_DODamage($date)
    {
      $this->date_of_damage = $date;
    }

    function set_DORecovry($date)
    {
      $this->date_of_recovery = $date;
    }

    function get_DODamage()
    {
      return $this->date_of_damage;
    }

    function get_DORecovry()
    {
      return $this->date_of_recovery;
    }

    function set_vehicle_num($v_number) {
        $this->vehicle->set_vehicle_num($v_number);
    } 

    function set_vehicle_type($v_type) {
      $this->vehicle->set_vehicle_type($v_type);
  }


  function set_veh_status($status) {
    $this->vehicle->set_vehicle_type($status);
}

function send_maintenanceData_toFacade()
{
  facade_obj->add_maintenanceData_ToDB($this->date_of_recovery, $this->date_of_damage, $vehicle->get_vehicle_num(), $vehicle->get_vehicle_type(), $vehicle->get_vehicle_num(), $vehicle->get_vehicle_status());
}  
 
}

$db_layer = new Technical_layer();
$vehicle = new Vehicle();
$maintenance =  new Maintenance($db_layer, $vehicle );
$maintenance ->set_vehicle_num($_POST["vehicle_no"]); //$_POST["vehicle_no"]
$maintenance ->set_vehicle_type( $_POST["vehicle_type"]); // $_POST["vehicle_type"]
$maintenance ->set_veh_status($_POST["vehicle_type"]);


// echo $vehicle_schedule->get_departure_time(). PHP_EOL ;
// $vehicle_schedule->get_location();
// $vehicle_schedule->get_vehicle_data() ;
?>