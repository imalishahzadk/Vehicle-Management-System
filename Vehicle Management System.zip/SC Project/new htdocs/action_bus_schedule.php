<?php
// require 'action_location.php';
// require 'action_vehicle.php';
// require 'facadeFetch.php';
// require 'show_bus_schedule.php';


// echo $_POST;
// exit();
// echo $_POST['routes'];
// echo $_POST['d_time'];
// echo $_POST['vehicle_type'];
// echo $_POST['vehicle_no'];]


class Vehicle_Schedule{
    private $departure_time;
    private $location;  
    private $vehicle;
    private $facade_obj;
  

#constructor
    function __construct(Location $loc, Vehicle $v, Technical_layer $f = null)  {
        $this->vehicle = $v;
        $this->location = $loc;
        $this->facade_obj =  $f;
      }

      
    function set_location($loc, $route)
    {
      $this->location->set_start_loc($loc);   
      $this->location->set_route($route);
    }         
    function set_departure_time($d_time) {
      $this->departure_time = $d_time;
    } 
    function set_vehicle_num($v_number) {
        $this->vehicle->set_vehicle_num($v_number);
    } 
    function set_vehicle_type($v_type) {
      $this->vehicle->set_vehicle_type($v_type);
  }
  function get_starting_point()
  {
   return $this->location->get_start_loc();
  }  

  function get_routes()
  {
   return $this->location->get_route();
  } 

  function get_vehicle_type()
  {
    return $this->vehicle->get_vehicle_type() ;
  }

  function get_vehicle_num()
  {
    return $this->vehicle->get_vehicle_num();
  }
  
  function get_departure_time() {
        return $this->departure_time;        
      }  

   ////////////////////////////////  Sending to Facade ////////////////
  function send_BS_toFacade()
  {
    facade_obj->add_bs_ToDB($this->departure_time, $location->get_start_loc(), $location->get_route(), $vehicle->get_vehicle_num(), $vehicle->get_vehicle_type(), $vehicle->get_vehicle_status());
  }  
 
  //////////////////////////////////////////  Sending data to Show Vehicle Schedule Class ///////////////
  function send_data_to_display_class ()
  {
      // display_schedule($this->get_departure_time(), get_starting_point(), get_routes(), get_vehicle_num(), get_vehicle_type());
  
      echo "<table class='table table-bordered table-hover'>
      <thead class='thead-dark'>
        <tr>
          <th>Departure Time</th>
          <th>Starting Location</th>
          <th>Ending Location</th>
          <th>Vehicle Number</th>
          <th>Vehicle Type</th>
        </tr>
      </thead>
      <tbody>";
echo 
"<tr>
<td>".$this->get_departure_time()."</td>
<td>".$this->get_starting_point()."</td>
<td>".$this->get_routes()."</td>
<td>".$this->get_vehicle_num()."</td>
<td>".$this->get_vehicle_type()."</td>
</tr>";

echo "</tbody></table>";


  
  
    }
   
}
// $db_layer = new Technical_layer();
// $location = new Location();
// $vehicle = new Vehicle();
// $vehicle_schedule =  new Vehicle_Schedule($location, $vehicle, $db_layer );
// $vehicle_schedule->set_departure_time($_POST['d_time']); //$_POST['d_time']
// $vehicle_schedule->set_location( "start", array($_POST["Start_point"], $_POST["routes"]));  // $_POST["Start_point"], $_POST["routes"]
// $vehicle_schedule->set_vehicle_num($_POST["vehicle_no"]); //$_POST["vehicle_no"]
// $vehicle_schedule->set_vehicle_type( $_POST["vehicle_type"]); // $_POST["vehicle_type"]
// $vehicle_schedule->send_BS_toFacade();



 ////////////////////////////////////////////////////  Passing data to Technical Layer ////////////////////////  

//  $d_time = $vehicle_schedule->get_departure_time();
//  $starting_loc = $location->get_start_loc();
//  $route = $location->get_route();
//  $vehicleNumber = $vehicle->get_vehicle_num();
//  $vehicleType = $vehicle->get_vehicle_type();
  
// echo $d_time ;
// echo $starting_loc;
// echo $route ;
// echo $vehicleNumber;
// echo $vehicleType;

//$db_layer->add_bs_ToDB($d_time, $starting_loc, $route, $vehicleNumber, $vehicleType);
?>
